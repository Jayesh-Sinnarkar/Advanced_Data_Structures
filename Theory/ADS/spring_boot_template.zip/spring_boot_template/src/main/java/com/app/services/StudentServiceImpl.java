package com.app.services;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dtos.ApiResponse;
import com.app.dtos.StudentDto;
import com.app.pojos.Student;
import com.app.respository.StudentRepository;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {
	@Autowired
	ModelMapper mapper;
	
	@Autowired
	StudentRepository studRepo;

	@Override
	public ApiResponse addNewStudent(StudentDto newStudent) {
		Student student = mapper.map(newStudent, Student.class);
		studRepo.save(student);
		return new ApiResponse("Student added succesfully");
	}

	@Override
	public List<Student> getAllStudents() {
		return studRepo.findAll();
	}

}
