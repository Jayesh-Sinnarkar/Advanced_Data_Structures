package com.app.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dtos.ApiResponse;
import com.app.dtos.StudentDto;
import com.app.services.StudentService;


@RestController
@RequestMapping("/student")
public class StudentController {

	@Autowired
	private StudentService studService;
	
	@PostMapping
	public ResponseEntity<?> enrollStudent(@RequestBody StudentDto newStudent)
	{
		try {
			return new ResponseEntity<>(studService.addNewStudent(newStudent), HttpStatus.OK);		
		} catch (RuntimeException e) {
			return new ResponseEntity<ApiResponse>(new ApiResponse(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	
	}

	@GetMapping
	public ResponseEntity<?> enrollStudent()
	{
		try {
			return new ResponseEntity<>(studService.getAllStudents(), HttpStatus.OK);		
		} catch (RuntimeException e) {
			return new ResponseEntity<ApiResponse>(new ApiResponse(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	
	}

	
	
	
	

	

}
