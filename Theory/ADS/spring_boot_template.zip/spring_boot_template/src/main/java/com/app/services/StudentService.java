package com.app.services;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dtos.ApiResponse;
import com.app.dtos.StudentDto;
import com.app.pojos.Student;


public interface StudentService {
	
	ApiResponse addNewStudent(StudentDto newStudent);

	List<Student> getAllStudents();
	
}
