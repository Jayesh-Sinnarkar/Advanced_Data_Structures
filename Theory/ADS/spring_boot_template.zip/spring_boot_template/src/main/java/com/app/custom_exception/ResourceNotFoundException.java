package com.app.custom_exception;

public class ResourceNotFoundException extends RuntimeException{
	
	private ResourceNotFoundException(String str)
	{
		super(str);
	}

}
